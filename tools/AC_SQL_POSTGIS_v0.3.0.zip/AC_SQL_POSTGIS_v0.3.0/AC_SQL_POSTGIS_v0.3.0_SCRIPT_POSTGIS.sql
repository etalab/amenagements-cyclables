CREATE EXTENSION postgis;

-- object: tr_amenagement_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_amenagement_ac CASCADE;
CREATE TABLE tr_amenagement_ac (
	id_amanegament_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_amenagement_ac_pk PRIMARY KEY (id_amanegament_ac)

);

-- object: tr_reseau_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_reseau_ac CASCADE;
CREATE TABLE tr_reseau_ac (
	id_reseau_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_reseau_ac_pk PRIMARY KEY (id_reseau_ac)

);

-- object: tr_regime_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_regime_ac CASCADE;
CREATE TABLE tr_regime_ac (
	id_regime_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_regime_ac_pk PRIMARY KEY (id_regime_ac)

);

-- object: tr_sens_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_sens_ac CASCADE;
CREATE TABLE tr_sens_ac (
	id_sens_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_sens_ac_pk PRIMARY KEY (id_sens_ac)

);

-- object: tr_statut_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_statut_ac CASCADE;
CREATE TABLE tr_statut_ac (
	id_statut_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_statut_ac_pk PRIMARY KEY (id_statut_ac)

);

-- object: tr_local_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_local_ac CASCADE;
CREATE TABLE tr_local_ac (
	id_local_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_local_ac_pk PRIMARY KEY (id_local_ac)

);

-- object: tr_roulable_ac | type: TABLE --
-- DROP TABLE IF EXISTS tr_roulable_ac CASCADE;
CREATE TABLE tr_roulable_ac (
	id_roulable_ac smallint NOT NULL,
	label character varying(255),
	CONSTRAINT tr_roulable_ac_pk PRIMARY KEY (id_roulable_ac)

);

-- object: amenagementcyclable_id_amenagementcyclable_seq | type: SEQUENCE --
-- DROP SEQUENCE IF EXISTS amenagementcyclable_id_amenagementcyclable_seq CASCADE;
CREATE SEQUENCE amenagementcyclable_id_amenagementcyclable_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 9223372036854775807
	START WITH 1
	CACHE 1
	NO CYCLE
	OWNED BY NONE;
-- ddl-end --

-- object: amenagementcyclable | type: TABLE --
-- DROP TABLE IF EXISTS amenagementcyclable CASCADE;
CREATE TABLE amenagementcyclable
(
    id_amenagementcyclable integer NOT NULL DEFAULT nextval('amenagementcyclable_id_amenagementcyclable_seq'::regclass),
    id_osm character varying(255) COLLATE pg_catalog."default",
    id_local character varying(255) COLLATE pg_catalog."default",
    code_commune character varying(5) COLLATE pg_catalog."default",
    num_iti character varying(100) COLLATE pg_catalog."default",
    id_reseau_ac smallint,
    nom_loc character varying(255) COLLATE pg_catalog."default",
    id_statut_ac smallint,
    id_amenagement_ac_d smallint,
    id_regime_ac_d smallint,
    id_sens_ac_d smallint,
    largeur_d double precision,
    id_local_ac_d smallint,
    id_amenagement_ac_g smallint,
    id_regime_ac_g smallint,
    id_sens_ac_g smallint,
    largeur_g double precision,
    id_local_ac_g smallint,
    id_roulable_ac smallint,
    d_maj date,
    trafic_vit integer,
    lumiere character varying(4) COLLATE pg_catalog."default",
    d_service character varying(100) COLLATE pg_catalog."default",
    commentaire text COLLATE pg_catalog."default",
    author character varying(100) COLLATE pg_catalog."default",
    create_date date,
    modifier character varying(100) COLLATE pg_catalog."default",
    update_date date,
    source character varying(50) COLLATE pg_catalog."default",
    project_c character varying(50) COLLATE pg_catalog."default",
    ref_geo character varying(50) COLLATE pg_catalog."default",
    geom geometry(LineString,2154),
    code_com_d character varying(5) COLLATE pg_catalog."default",
    code_com_g character varying(5) COLLATE pg_catalog."default",
    id_statut_ac_g smallint,
    id_statut_ac_d smallint,
CONSTRAINT amenagementcyclable_pk PRIMARY KEY (id_amenagementcyclable)
);

-- object: update_amenagementcyclable_author | type: FUNCTION --
-- DROP FUNCTION IF EXISTS update_amenagementcyclable_author() CASCADE;
CREATE FUNCTION update_amenagementcyclable_author ()
	RETURNS trigger
	LANGUAGE plpgsql
	VOLATILE 
	CALLED ON NULL INPUT
	SECURITY INVOKER
	COST 100
	AS $$

BEGIN
    NEW.author := "current_user"();
    RETURN NEW;
END;

$$;

-- object: update_amenagementcyclable_author | type: TRIGGER --
-- DROP TRIGGER IF EXISTS update_amenagementcyclable_author ON amenagementcyclable CASCADE;
CREATE TRIGGER update_amenagementcyclable_author
	BEFORE INSERT 
	ON amenagementcyclable
	FOR EACH ROW
	EXECUTE PROCEDURE update_amenagementcyclable_author();
-- ddl-end --

-- object: update_amenagementcyclable_modifier | type: FUNCTION --
-- DROP FUNCTION IF EXISTS update_amenagementcyclable_modifier() CASCADE;
CREATE FUNCTION update_amenagementcyclable_modifier ()
	RETURNS trigger
	LANGUAGE plpgsql
	VOLATILE 
	CALLED ON NULL INPUT
	SECURITY INVOKER
	COST 100
	AS $$

BEGIN
    NEW.modifier := "current_user"();
    RETURN NEW;
END;

$$;

-- object: update_amenagementcyclable_create_date | type: FUNCTION --
-- DROP FUNCTION IF EXISTS update_amenagementcyclable_create_date() CASCADE;
CREATE FUNCTION update_amenagementcyclable_create_date ()
	RETURNS trigger
	LANGUAGE plpgsql
	VOLATILE 
	CALLED ON NULL INPUT
	SECURITY INVOKER
	COST 100
	AS $$

BEGIN
    NEW.create_date := "now"();
    RETURN NEW;
END;

$$;

-- object: update_amenagementcyclable_update_date | type: FUNCTION --
-- DROP FUNCTION IF EXISTS update_amenagementcyclable_update_date() CASCADE;
CREATE FUNCTION update_amenagementcyclable_update_date ()
	RETURNS trigger
	LANGUAGE plpgsql
	VOLATILE 
	CALLED ON NULL INPUT
	SECURITY INVOKER
	COST 100
	AS $$

BEGIN
    NEW.update_date := "now"();
    RETURN NEW;
END;

$$;

-- object: update_amenagementcyclable_create_date | type: TRIGGER --
-- DROP TRIGGER IF EXISTS update_amenagementcyclable_create_date ON amenagementcyclable CASCADE;
CREATE TRIGGER update_amenagementcyclable_create_date
	BEFORE INSERT 
	ON amenagementcyclable
	FOR EACH ROW
	EXECUTE PROCEDURE update_amenagementcyclable_create_date();
-- ddl-end --

-- object: update_amenagementcyclable_modifier | type: TRIGGER --
-- DROP TRIGGER IF EXISTS update_amenagementcyclable_modifier ON amenagementcyclable CASCADE;
CREATE TRIGGER update_amenagementcyclable_modifier
	BEFORE UPDATE
	ON amenagementcyclable
	FOR EACH ROW
	EXECUTE PROCEDURE update_amenagementcyclable_modifier();
-- ddl-end --

-- object: update_amenagementcyclable_update_date | type: TRIGGER --
-- DROP TRIGGER IF EXISTS update_amenagementcyclable_update_date ON amenagementcyclable CASCADE;
CREATE TRIGGER update_amenagementcyclable_update_date
	BEFORE UPDATE
	ON amenagementcyclable
	FOR EACH ROW
	EXECUTE PROCEDURE update_amenagementcyclable_update_date();
-- ddl-end --

-- object: tr_booleen | type: TABLE --
-- DROP TABLE IF EXISTS tr_booleen CASCADE;
CREATE TABLE tr_booleen (
	id_booleen character varying(4) NOT NULL,
	booleen character varying(36),
	CONSTRAINT tr_booleen_pkey PRIMARY KEY (id_booleen)

);

-- object: tr_commune | type: TABLE --
-- DROP TABLE IF EXISTS tr_commune CASCADE;
CREATE TABLE tr_commune (
	code_commune character varying(5) NOT NULL,
	commune character varying(100) NOT NULL,
	code_epci character varying(9) NOT NULL,
	code_dep character varying(3) NOT NULL,
	code_reg character varying(2) NOT NULL,
	CONSTRAINT tr_commune_pkey PRIMARY KEY (code_commune)

);

-- object: fk_code_com_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_code_com_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_code_com_d FOREIGN KEY (code_com_d)
REFERENCES tr_commune (code_commune) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_code_com_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_code_com_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_code_com_g FOREIGN KEY (code_com_g)
REFERENCES tr_commune (code_commune) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_reseau_ac | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_reseau_ac CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_reseau_ac FOREIGN KEY (id_reseau_ac)
REFERENCES tr_reseau_ac (id_reseau_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_statut_ac_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_statut_ac_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_statut_ac_d FOREIGN KEY (id_statut_ac_d)
REFERENCES tr_statut_ac (id_statut_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_statut_ac_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_statut_ac_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_statut_ac_g FOREIGN KEY (id_statut_ac_g)
REFERENCES tr_statut_ac (id_statut_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_amenagement_ac_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_amenagement_ac_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_amenagement_ac_d FOREIGN KEY (id_amenagement_ac_d)
REFERENCES tr_amenagement_ac (id_amanegament_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_amenagement_ac_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_amenagement_ac_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_amenagement_ac_g FOREIGN KEY (id_amenagement_ac_g)
REFERENCES tr_amenagement_ac (id_amanegament_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_regime_ac_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_regime_ac_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_regime_ac_d FOREIGN KEY (id_regime_ac_d)
REFERENCES tr_regime_ac (id_regime_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_regime_ac_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_regime_ac_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_regime_ac_g FOREIGN KEY (id_regime_ac_g)
REFERENCES tr_regime_ac (id_regime_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_sens_ac_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_sens_ac_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_sens_ac_d FOREIGN KEY (id_sens_ac_d)
REFERENCES tr_sens_ac (id_sens_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_sens_ac_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_sens_ac_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_sens_ac_g FOREIGN KEY (id_sens_ac_g)
REFERENCES tr_sens_ac (id_sens_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_local_ac_d | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_local_ac_d CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_local_ac_d FOREIGN KEY (id_local_ac_d)
REFERENCES tr_local_ac (id_local_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_local_ac_g | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_local_ac_g CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_local_ac_g FOREIGN KEY (id_local_ac_g)
REFERENCES tr_local_ac (id_local_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_id_roulable_ac | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_id_roulable_ac CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_id_roulable_ac FOREIGN KEY (id_roulable_ac)
REFERENCES tr_roulable_ac (id_roulable_ac) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- object: fk_lumiere | type: CONSTRAINT --
-- ALTER TABLE amenagementcyclable DROP CONSTRAINT IF EXISTS fk_lumiere CASCADE;
ALTER TABLE amenagementcyclable ADD CONSTRAINT fk_lumiere FOREIGN KEY (lumiere)
REFERENCES tr_booleen (id_booleen) MATCH FULL
ON DELETE NO ACTION ON UPDATE NO ACTION;
-- ddl-end --

-- -- object: public.geometry | type: TYPE --
-- -- DROP TYPE IF EXISTS public.geometry CASCADE;
-- CREATE TYPE public.geometry;
-- -- ddl-end --
-- 
INSERT INTO public.tr_amenagement_ac(
	id_amanegament_ac, label)	
	VALUES (1,'PISTE CYCLABLE'),
 	(2,'BANDE CYCLABLE'),
 	(3,'DOUBLE SENS CYCLABLE PISTE'),
 	(4,'DOUBLE SENS CYCLABLE BANDE'),
 	(5,'DOUBLE SENS CYCLABLE NON MATERIALISE'),
 	(6,'VOIE VERTE'),
 	(7,'VELO-RUE'),
 	(8,'COULOIR BUS-VELO'),
 	(9,'RAMPE'),
 	(10,'GOULOTTE'),
 	(11,'AMENAGEMENTS MIXTES PIETON/VÉLO HORS VOIE VERTE'),
 	(12,'CHAUSSEE À  VOIE CENTRALE BANALISEE'),
 	(13,'ACCOTEMENT REVETU HORS CVCB'),
 	(14,'AUCUN'),
 	(15,'AUTRE');


INSERT INTO public.tr_booleen(
	id_booleen, booleen)
	VALUES ('',''),
 	('F','FAUX / NON'),
 	('N','NE SAIT PAS / N"A PAS D"INFORMATION'),
 	('T','VRAI / OUI');

INSERT INTO public.tr_local_ac(
	id_local_ac, label)
	VALUES (1,'TROTTOIR'),
 	(2,'CHAUSSEE'),
	(3,'INTERMEDIARE');

INSERT INTO public.tr_regime_ac(
	id_regime_ac, label)
	VALUES (1,'ZONE 30'),
 	(2,'AIRE PIETONNE'),
 	(3,'ZONE DE RENCONTRE'),
 	(4,'EN AGGLOMERATION'),
 	(5,'HORS AGGLOMERATION'),
 	(6,'AUTRE');

INSERT INTO public.tr_reseau_ac(
	id_reseau_ac, label)
	VALUES (1,'REV'),
 	(2,'STRUCTURANT'),
 	(3,'AUTRE');

INSERT INTO public.tr_roulable_ac(
	id_roulable_ac, label)
	VALUES (1,'ROLLER'),
 	(2,'VTT'),
 	(3,'VTC'),
 	(4,'VELO DE ROUTE');

INSERT INTO public.tr_sens_ac(
	id_sens_ac, label)
	VALUES (1,'UNIDIRECTIONNEL'),
 	(2,'BIDIRECTIONNEL');

INSERT INTO public.tr_statut_ac(
	id_statut_ac, label)
	VALUES (1,'EN TRAVAUX'),
 	(2,'EN SERVICE'),
 	(3,'PROVISOIRE'),
 	(4,'EN PROJET');
